﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataStructuresImplementation
{
    interface IDataStructureInterface   //interface
    {
        void Display();
        void Add(int n);
        void Sort();
       
    }
}
