﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataStructuresImplementation
{
    class Program
    {
        
        public void Display()     //starting display
        {
           
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("|--------------------------------------------------|");
            Console.WriteLine("|-------------------Data Structures----------------|");
            Console.WriteLine("|--------------------------------------------------|");
            Console.WriteLine("|1----To Implement Stack.                          |");
            Console.WriteLine("|2----To Implement Queue.                          |");
            Console.WriteLine("|3----To Implement Linked List.                    |");
            Console.WriteLine("|4----To Exit.                                     |");
            Console.WriteLine("|--------------------------------------------------|");
            Console.WriteLine("Enter Choice:");
            Console.ForegroundColor = ConsoleColor.White;
            int choice = int.Parse(Console.ReadLine());
            switch(choice) { 
                case 1:                      //implementing stack
                    {
                        Console.Clear();
                        Stack stack = new Stack();
                        stack.Inputs();
                        break;
                    }

                case 2:                     //implementing Queue
                    {
                        Console.Clear();
                        Queue stack = new Queue();
                        stack.QueueInputs();
                        break;
                    }
                case 3:                    //impementing Linked List 
                    {
                        Console.Clear();
                        LinkedList linkedList = new LinkedList();
                        linkedList.LinkedListInputs();
                        break;
                    }
                case 4:
                    {
                        Environment.Exit(0);
                        break;
                    }
                default:
                    {
                        Console.Clear();
                        Console.WriteLine("Invalid option");
                        break;
                    }
            }
        }
        static void Main(string[] args)
        {
            Program obj = new Program();
            obj.Display();
        }
    }
}
