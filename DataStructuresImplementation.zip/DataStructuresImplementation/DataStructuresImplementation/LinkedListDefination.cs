﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataStructuresImplementation
{
    class LinkedListDefination               //creating structure of node to implement linked list
    {
        public int Value;
       public LinkedListDefination Next=null;  //stores the next address
        public LinkedListDefination(int Data)
        {
            Value = Data;
          
        }
    }
}
