﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataStructuresImplementation
{
    class Stack:IDataStructureInterface
    {
        int top = -1;
        int[] StackArray = new int[15];
        public void Inputs()
        {
            Console.WriteLine("1--Add");
            Console.WriteLine("2--Remove Top Element");
            Console.WriteLine("3--To check Top element");
            Console.WriteLine("4--To Sort the Stack");
            Console.WriteLine("5--To Display");
            Console.WriteLine("6--Exit");
            Console.WriteLine("Enter Choice:");
            int choice = int.Parse(Console.ReadLine());
            
            switch (choice)
            {
                case 1:                        //push element in statck
                    {
                        Console.Clear();
                        Console.WriteLine("Enter the element to add in stack:");
                        int element = int.Parse(Console.ReadLine());
                        Add(element);
                        Inputs();
                        break;
                    }

                case 2:                      //pop element in stack
                    {
                        Console.Clear();
                        Remove();
                        Inputs();
                        break;
                    }
                case 3:                     //to find element at peek 
                    {
                        Console.Clear();
                        int topElement = StackArray[top];
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("Top Element in Stack: {0}",topElement);
                        Console.ForegroundColor = ConsoleColor.White;
                        Inputs();
                        break;
                    }
                case 4:             //sort stack elements
                    {
                        Console.Clear();
                        Sort();
                        Inputs();
                        break;
                    }
                case 5:            //display stack elements
                    {
                        Console.Clear();
                        Display();
                        Inputs();
                        break;
                    }

                case 6:
                    {
                        Console.Clear();
                        Program obj = new Program();
                        obj.Display();
                        break;
                    }
                default:
                    {
                        Console.Clear();
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Invalid Option");
                        Console.ForegroundColor = ConsoleColor.White;
                        Inputs();
                        break;
                    }
            }
        }
        public void Sort()
        {
            int[] sorting = new int[15];
            int topTemp = top;
           for(int Transfer=0;Transfer<topTemp+1;Transfer++)
            {
               
                sorting[Transfer] = StackArray[top];
                top = top - 1;
            }
           for(int loop1=0;loop1<topTemp+1;loop1++)
            {
                for (int loop2 = loop1+1; loop2 < topTemp + 1; loop2++)
                {
                    if (sorting[loop1] > sorting[loop2])
                    {
                        int Swap = sorting[loop1];
                        sorting[loop1] = sorting[loop2];
                        sorting[loop2] = Swap;
                    }
                }
                }
                for (int BackTransfer = 0; BackTransfer<topTemp+1; BackTransfer++)
            {
                top += 1;
                StackArray[top] =sorting[BackTransfer];
                
               }
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Stack Sorted Successfully.");
            Console.ForegroundColor = ConsoleColor.White;
        }
        public void Add(int data)
        {
            if (top > 12)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Sorry, Stack is full");
                Console.ForegroundColor = ConsoleColor.White;
            }
            else
            {
                top += 1;
                StackArray[top] = data;
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("Data added to Stack");
                Console.ForegroundColor = ConsoleColor.White;
            }
        }
        public void Remove()
        {
            if (top<=-1)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Sorry, Stack is empty");
                Console.ForegroundColor = ConsoleColor.White;
            }
            else
            {
                int topElement = StackArray[top];
                top -= 1;
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("Data removed from Stack");
                Console.ForegroundColor = ConsoleColor.White;
            }
        }
       
        public void Display()
        {
            if (top == -1)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Stack is Empty");
                Console.ForegroundColor = ConsoleColor.White;
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Elements in Stack are: ");
                Console.ForegroundColor = ConsoleColor.White;
                for (int dataValue = 0; dataValue <= top; dataValue++)
                    Console.Write(StackArray[dataValue] + " ");
                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine();
            }
        }
    }
}
