﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataStructuresImplementation
{
    class Queue:IDataStructureInterface
    {
        int front = -1,rear=-1;
        int[] QueueArray = new int[15];

        public int FrontElement { get; private set; }

        public void QueueInputs()
        {
            Console.WriteLine("1--Add");
            Console.WriteLine("2--Remove Front Element");
            Console.WriteLine("3--To check Front element");
            Console.WriteLine("4--To Sort the Queue");
            Console.WriteLine("5--Is Full");
            Console.WriteLine("6--Is Empty");
            Console.WriteLine("7--To Display Queue");
            Console.WriteLine("8--Exit");
            Console.WriteLine("Enter Choice:");
            int choice = int.Parse(Console.ReadLine());

            switch (choice)
            {
                case 1:                                   //add element in queue
                    {
                        Console.Clear();
                        Console.WriteLine("Enter the element to add in Queue:");
                        int element = int.Parse(Console.ReadLine());
                        Add(element);
                        QueueInputs();
                        break;
                    }

                case 2:                                  //Remove element in queue
                    {
                        Console.Clear();
                        Remove();
                        QueueInputs();
                        break;
                    }
                case 3:                                 //to get front element in queue
                    {
                        Console.Clear();
                        if (peek()!=-1) 
                         FrontElement = peek();
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("First Element in Queue: {0}", FrontElement);
                        Console.ForegroundColor = ConsoleColor.White;
                        QueueInputs();
                        break;
                    }
                case 4:                                    //To sort element in queue
                    { Console.Clear();
                        Sort();
                        QueueInputs();
                        break;
                    }
                case 5:                                           //Isfull()
                    {
                        Console.Clear();
                        if (isFull())
                        {
                            Console.WriteLine("True");
                        }
                        else
                        {
                            Console.WriteLine("True");
                        }
                        QueueInputs();
                        break;
                    }
                case 6:                                       //isEmpty()
                    {
                        Console.Clear();
                        if (isEmpty())
                        {
                            Console.WriteLine("True");
                        }
                        else
                        {
                            Console.WriteLine("True");
                        }
                        QueueInputs();
                        break;
                    }

                case 7:                                           //Display queue
                    {
                        Console.Clear();
                        Display();
                        QueueInputs();
                        break;
                    }

                case 8:
                    {
                        Console.Clear();
                        Program obj = new Program();
                        obj.Display();
                        break;
                    }
                default:
                    {
                        Console.Clear();
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Invalid Option");
                        Console.ForegroundColor = ConsoleColor.White;
                        QueueInputs();
                        break;
                    }
            }
        }
        public void Sort()
        {
            int[] sorting = new int[15];
            int topTemp =rear+1;
            for (int Transfer = 0; Transfer <topTemp; Transfer++)
            {
                sorting[Transfer] = QueueArray[front];
                front = front+1;
            }
                  for (int loop1 = 0; loop1 <topTemp; loop1++)
                   {
                       for (int loop2 = loop1 + 1; loop2 <topTemp; loop2++)
                       {
                           if (sorting[loop1] > sorting[loop2])
                           {
                               int Swap = sorting[loop1];
                               sorting[loop1] = sorting[loop2];
                               sorting[loop2] = Swap;
                           }
                       }
                   }
            front = 0;
            rear = -1;
            for (int BackTransfer = 0; BackTransfer < topTemp; BackTransfer++)
                   {
                
                       rear += 1;
                       QueueArray[rear] = sorting[BackTransfer];

                   }
                Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Stack Sorted Successfully.");
            Console.ForegroundColor = ConsoleColor.White;
        }
        public bool isFull()
        {
            if (front == 0 && rear == 14)
                return true;
            return false;
        }
        public bool isEmpty()
        {
            if (front == -1 && rear == -1)
                return true;
            return false;
        }
        public int peek()
        {
            if(!isEmpty())
            {
                return QueueArray[front];
            }
            else
            {
                return -1;
            }
        }
        public void Add(int data)
        {
            if (isFull())
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Sorry, Queue is full");
                Console.ForegroundColor = ConsoleColor.White;
            }
            else
            {
                if(front==-1)
                {
                    front = 0;
                }
                rear += 1;
              QueueArray[rear] = data;
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("Data added to Queue");
                Console.ForegroundColor = ConsoleColor.White;
            }
        }
        public void Remove()
        {
            if (isEmpty())
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Sorry, Queue is empty");
                Console.ForegroundColor = ConsoleColor.White;
            }
            else
            {
                int frontElement = QueueArray[front];
                if (front >= rear)
                {
                    front = -1;
                    rear = -1;
                }
                else
                {
                    front += 1;
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("Data removed from Queue");
                    Console.ForegroundColor = ConsoleColor.White;
                }
            }
        }
        
        public void Display()
        {
            if (!isEmpty())
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Elements in Queue are: ");
                for (int dataValue = front; dataValue <= rear; dataValue++)
                    Console.Write(QueueArray[dataValue] + " ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine();
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Queue is empty");
                Console.ForegroundColor = ConsoleColor.White;
            }
        }
    
}
}
