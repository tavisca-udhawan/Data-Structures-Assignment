﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataStructuresImplementation
{
    class LinkedList :IDataStructureInterface    
    {
        LinkedListDefination Head=null;
        int addCheck = 0;
        public void LinkedListInputs()           //taking inputs
        {
            Console.WriteLine("1--Add Element");
            Console.WriteLine("2--Remove Element");
            Console.WriteLine("3--To Sort List");
            Console.WriteLine("4--To Display LinkedList");
            Console.WriteLine("5--Exit");
            Console.WriteLine("Enter Choice:");
            int choice = int.Parse(Console.ReadLine());

            switch (choice)
            {
                case 1:                                //add elements
                    {
                        
                        Console.Clear();
                        addCheck += 1;
                        Console.WriteLine("1--At Front");
                        Console.WriteLine("2--At End");
                        Console.WriteLine("3--At Some Position");
                        Console.WriteLine("Enter Choice:");
                        int EntryChoice = int.Parse(Console.ReadLine());
                        switch (EntryChoice)
                        {
                            case 1:               //add at front
                                {
                                    Console.Clear();
                                    Console.WriteLine("Enter the Number to Add");
                                    int Number = int.Parse(Console.ReadLine());
                                    Add(Number);
                                    break;
                                }
                                case 2:                      //add at last
                                {
                                    Console.Clear();
                                    Console.WriteLine("Enter the Number to Add");
                                    int Number = int.Parse(Console.ReadLine());
                                    AddAtLast(Number);
                                    break;
                                }
                            case 3:          //Add at particular position
                                {
                                    Console.Clear();
                                    Console.WriteLine("Enter the position");
                                    int position = int.Parse(Console.ReadLine());
                                    Console.WriteLine("Enter the Number to Add:");
                                    int Number = int.Parse(Console.ReadLine());
                                    AddAtPosition(Number,position);
                                    break;
                                }
                                default:
                                {
                                    Console.Clear();
                                     Console.ForegroundColor = ConsoleColor.Red;
                                    Console.WriteLine("Invalid Choice");
                 Console.ForegroundColor = ConsoleColor.White;
                                    break;
                                }
                        }
                        LinkedListInputs();
                        break;
                    }

                case 2:              //remove at particular position
                    {
                        Console.Clear();
                        Console.WriteLine("Enter the position");
                        int position = int.Parse(Console.ReadLine());
                        RemoveAtPosition(position,Head);
                        LinkedListInputs();
                        break;
                    }
                case 3:               //sort the list
                    {

                        Console.Clear();
                        Sort();
                        LinkedListInputs();
                        break;
                    }
                case 4:           //display
                    {
                        Console.Clear();
                        Display();
                        LinkedListInputs();
                        break;
                    }

                case 5:
                    {
                        Console.Clear();
                        Program obj = new Program();
                        obj.Display();
                        break;
                    }
                default:
                    {
                        Console.Clear();
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Invalid Option");
                        Console.ForegroundColor = ConsoleColor.White;
                       LinkedListInputs();
                        break;
                    }
            }
        }
        public void AddAtFront(int data)   
        {
            LinkedListDefination AddFront = new LinkedListDefination(data);
              AddFront.Value = data;
                AddFront.Next = Head;
                Head = AddFront;
        }
        public void AddAtLast(int data)
        {
            LinkedListDefination TempAdd=Head;
            LinkedListDefination AddLast = new LinkedListDefination(data);
            while(TempAdd.Next!=null)
            {
                TempAdd = TempAdd.Next;
            }
            TempAdd.Next = AddLast;
            AddLast.Value = data;
            
        }
        public void AddAtPosition(int Number,int position)
        {
            LinkedListDefination TempCheck = Head;
            LinkedListDefination PrevCheck=Head;
            LinkedListDefination TempAdd = Head;
            LinkedListDefination AddLast = new LinkedListDefination(Number);

            if (addCheck < position)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Invalid position, Maximum position is {0}"+addCheck);
                Console.ForegroundColor = ConsoleColor.White;
            }
            else if (position == 1)
            {
                AddAtFront(Number);
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("Element added in Linked List");
                Console.ForegroundColor = ConsoleColor.White;
            }
            else
            {
                while (--position > 0)
                {
                    PrevCheck = TempCheck;
                    TempCheck = TempCheck.Next;
                }
                PrevCheck.Next = AddLast;
                AddLast.Next = TempCheck;
                AddLast.Value = Number;
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("Element added in Linked List");
                Console.ForegroundColor = ConsoleColor.White;
            }
           
        }
        public void Sort(LinkedListDefination Head)
        {
            LinkedListDefination FrontHead = null;
            LinkedListDefination FrontMove = Head;
            while(FrontMove!=null)
            {
                FrontHead = FrontMove.Next;
                while (FrontHead != null)
                {
                   if (FrontMove.Value > FrontHead.Value)
                    {
                        int swapData = FrontMove.Value;
                        FrontMove.Value = FrontHead.Value;
                        FrontHead.Value = swapData;
                    }
                    FrontHead = FrontHead.Next;
                }
                FrontMove = FrontMove.Next;
            }
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Data Sorted Successfully from linked list");
            Console.ForegroundColor = ConsoleColor.White;
        }
        public void RemoveAtPosition(int position,LinkedListDefination Head)         //deleting node at particular position from linked list
        {
            LinkedListDefination deleteData;
            if (Head == null)
                return;
            
        deleteData = Head;
 if (position == 1)
    {
        Head= deleteData.Next;   }
 
    for (int i=1; deleteData!=null && i<position; i++)
         deleteData = deleteData.Next;
 
    if (deleteData ==null || deleteData.Next ==null)
         return;
 LinkedListDefination AssignData = deleteData.Next.Next;
            
   deleteData.Next = AssignData;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Data Deleted Successfully from linked list");
            Console.ForegroundColor = ConsoleColor.White;
        }

        public void Display()                 //displaying linked list
        {
            LinkedListDefination printData = Head;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write("Elements in Linked List: ");
            while (printData!=null)
            {
                Console.Write(printData.Value+" ");
                printData =printData.Next;

            }
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine();
        }

        public void Add(int n)                  //method to add element at front
        {
            AddAtFront(n);
            
        }

        public void Sort()
        {
            Sort(Head);
            throw new NotImplementedException();
        }
    }
}

